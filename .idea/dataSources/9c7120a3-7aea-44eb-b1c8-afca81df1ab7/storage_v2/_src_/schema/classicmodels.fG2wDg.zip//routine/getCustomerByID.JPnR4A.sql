create
    definer = root@localhost procedure getCustomerByID(IN cusNum int)
BEGIN 
SELECT * FROM CUSTOMERS where customerNumber = cusNum;
END;

