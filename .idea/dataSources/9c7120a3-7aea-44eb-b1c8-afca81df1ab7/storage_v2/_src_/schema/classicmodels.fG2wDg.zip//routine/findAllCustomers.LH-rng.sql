create
    definer = root@localhost procedure findAllCustomers()
begin 
select * from customers;
end;

