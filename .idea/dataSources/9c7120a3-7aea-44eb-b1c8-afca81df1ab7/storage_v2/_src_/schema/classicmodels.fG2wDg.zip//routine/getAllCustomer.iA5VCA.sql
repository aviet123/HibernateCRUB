create
    definer = root@localhost procedure getAllCustomer()
BEGIN 
SELECT * FROM CUSTOMERS where customerNumber = 175;
END;

